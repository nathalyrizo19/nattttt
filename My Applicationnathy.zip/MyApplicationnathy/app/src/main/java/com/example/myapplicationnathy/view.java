package com.example.myapplicationnathy;

public class view {
}
